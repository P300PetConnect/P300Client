const AWS = require('aws-sdk');
const ddb = new AWS.DynamoDB.DocumentClient({ region: 'eu-west-1' });

exports.handler = async (event, context) => {
     try{
       const response = {
       statusCode: 204,
       headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin':'*'
    },
    body: "test"
    };
    let ddbParams = {
          TableName: 'Forum-Comments',
  Item: {                
                'postID' : event.postID,
                "commentID": event.commentID,
                "user" : event.user,
                'date': event.datePost,
                'comment': event.comment, 
                'voteCount': event.voteCount
        }
        };
        
        console.log(ddbParams)

    await ddb.put(ddbParams).promise();
    return response;
    
    }catch(err){
        console.log("Error", err);
      
    }
   
   console.log("Success: Everything executed correctly");
        context.done(null, event);
};

