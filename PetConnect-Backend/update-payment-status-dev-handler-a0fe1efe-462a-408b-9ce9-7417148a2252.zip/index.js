const {
  Pool
} = require('pg')

var result; 

const pool = new Pool({
  user: 'postgres',
  host: 'petconnect.cluster-ro-cofkqdav0xcm.eu-west-1.rds.amazonaws.com',
  database: 'petconnect',
  password: 'admin2022',
  port: 5425
});

exports.handler = async (event, context, callback) => {

  let PaymentStatus = event.PaymentStatus; 
  //let Status; 
 //let OrderID = 56; 
  
  var getOrders = `UPDATE public."OrderTBL"
SET "PaymentStatus" = '${PaymentStatus}'
WHERE public."OrderTBL"."OrderID"=${event.OrderID}`
  try {
    const client = await pool.connect()
    console.log(getOrders)
    result = await client.query({
    text: getOrders,
    })

  } catch (err) {

    callback(null, "Failed to Connect Successfully");
    throw err;
    //error message
  }

  let message = {
    'message': 'Execution started successfully!'
  }
  return {
    'statusCode': 200,
    'headers': {
      'Content-Type': 'application/json'
    },
    'body': event

  }
};