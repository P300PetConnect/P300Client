import json
import boto3

def lambda_handler(event, context):
    client = boto3.client("ses")
    subject = "You have a new message!"
    body = "<img src='https://s3-images-web-ca2.s3.eu-west-1.amazonaws.com/emaillogo.png' width='100%' height='100%' alt='logo'><h1>Hello User!</h1><br><p>You have a new message!</p><br><a href='http://localhost:4200/chat'>Click Here To Open!</a>"
    message = {"Subject": {"Data": subject}, "Body": {"Html": {"Data": body}}}
    response = client.send_email(Source = "petconnectapp@outlook.com",
               Destination = {"ToAddresses": ["akmenz@yahoo.ie"]}, Message = message)
    return response
