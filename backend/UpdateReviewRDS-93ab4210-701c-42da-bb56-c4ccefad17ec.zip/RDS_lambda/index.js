//this imports the postgres connector into the file so it can be used
//const { Client } = require('pg');
const { Pool } = require('pg')
 
var result;

const pool = new Pool({
    user: 'postgres',
    host: 'petconnect.cluster-ro-cofkqdav0xcm.eu-west-1.rds.amazonaws.com',
    database: 'petconnect',
    password: 'admin2022',
    port: 5425
});
 
//the lambda funtion code
exports.handler = async (event, context, callback) => {

let id = parseInt(event["queryStringParameters"]['id']);
let reviewAmount = parseInt(event["queryStringParameters"]['reviewAmount']);

var getServices = 'UPDATE public."ReviewTBL" SET "NumReviews" = "NumReviews" + 1, "ReviewsTotal" = "ReviewsTotal"+ '+reviewAmount+' WHERE "UserID" = ' + id
    try {

const client = await pool.connect()
result = await client.query({
  
  text: getServices,
})
return {
    'statusCode': 200,
    'headers': {'Content-Type': 'application/json'},
    
}

    } catch (err) {

        callback(null, "Failed to Connect Successfully");
        throw err;
        //error message
    }





};