const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({ region: 'eu-west-1' });
 // event["queryStringParameters"]['postID']


exports.handler = (event, context, callback) => {
 
    var params = {
  TableName: 'Forum-Data',
  FilterExpression : "contains(#BoardID, :BoardID)",
    ExpressionAttributeNames: { "#BoardID": "BoardID" },
    ExpressionAttributeValues: {
        ':BoardID': event["queryStringParameters"]['BoardID']
    }
    }

    docClient.scan(params, function (err, data) {
      if (err) {
        console.log(err, err.stack) // an error occurred
      } else {
        console.log(data) // successful response
        callback(null, data.Items)
      }
    })
 
  }



