//this imports the postgres connector into the file so it can be used
//const { Client } = require('pg');
const { Pool } = require('pg')
 
var result;

const pool = new Pool({
    user: 'postgres',
    host: 'petconnect.cluster-ro-cofkqdav0xcm.eu-west-1.rds.amazonaws.com',
    database: 'petconnect',
    password: 'admin2022',
    port: 5425
});
 
//the lambda funtion code
exports.handler = async (event, context, callback) => {

let subjectID = parseInt(event["queryStringParameters"]['id'])

//let subjectID = 43;

var getReviews = 

`SELECT O."PetSitterID", to_char("OrderDate", 'DD Mon YYYY') AS formatted_date, O."PetOwnerID", O."OrderDate", O."OrderDescription", 
O."OrderID", O."ServiceID", O."Price", O."PaymentStatus", O."Status", P."UserID",
U."Name", U."Surname", U."Profile_Pic_URL", A."AdressID", A."Line_1", A."Line_2", A."County", O."OrderStartDate", O."OrderEndDate",
S."ServiceTitle", S."UserTitle", S."Description" as ServiceDes
FROM Public."OrderTBL" as O
INNER JOIN public."PetOwnerTBL" as P 
ON P."PetOwnerID" = O."PetOwnerID"
INNER JOIN public."UserTBL" as U 
ON U."UserID" = P."UserID"
INNER JOIN public."AddressTBL" as A
ON A."AdressID" = U."AdressID"
INNER JOIN public."ServiceTBL" as S
ON O."ServiceID" = S."ServiceID"
WHERE O."PetSitterID" = ${subjectID}
ORDER BY O."OrderDate"`

    try {

const client = await pool.connect()
result = await client.query({
  
  text: getReviews,
})
console.log(result.fields[0].name) // one
console.log(result.fields[1].name) // two
console.log(result.rows) // [ [ 1, 2 ] ]

    } catch (err) {

        callback(null, "Failed to Connect Successfully");
        throw err;
        //error message
    }

let message = {
   'message': 'Execution started successfully!'
}
return {
    'statusCode': 200,
    'headers': {'Content-Type': 'application/json'},
    'body': JSON.stringify(result.rows)
}


};