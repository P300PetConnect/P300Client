
const AWS = require('aws-sdk');
const ddb = new AWS.DynamoDB.DocumentClient({ region: 'eu-west-1' });

exports.handler = async (event, context) => {
    console.log(event);

    let date = new Date();

        // -- Write data to DDB
      let ddbParams = {
          TableName: 'Forum-Comments',
  Item: {                
                'postID' : event.postID,
                'commentID' : event.commentID,
                'user': event.user,
                'comment':  event.comment,
                'voteCount': 0,
                'date': event.datePost,
                'imageURL': event.imageURL
                
              }
            
        };
        
        console.log(ddbParams)
try {
    const response = {
       statusCode: 200,
       headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin':'*'
    },
    body: JSON.stringify(ddbParams)
    };
    await ddb.put(ddbParams).promise()
    return response;
     
      
        } catch (err) {
            console.log("Error", err);
        }

        console.log("Success: Everything executed correctly");
        context.done(null, event);

   
};
