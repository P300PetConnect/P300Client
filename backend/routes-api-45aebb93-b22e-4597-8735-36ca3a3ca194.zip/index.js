const AWS = require('aws-sdk');
AWS.config.update( {
  region: 'eu-west-1'
});
const dynamodb = new AWS.DynamoDB.DocumentClient();
const dynamodbTableName = 'routesTBL';
const addroutePath = '/addroute';
const routePath = '/route';
const routesPath = '/routes2';

exports.handler = async function(event) {
  console.log('Request event: ', event);
  let response;
  switch(true) {
    case event.httpMethod === 'GET' && event.path === addroutePath:
      response = buildResponse(200);
      break;
    case event.httpMethod === 'GET' && event.path === routePath:
      response = await getRoute(event.queryStringParameters.userid);
      break;
    case event.httpMethod === 'GET' && event.path === routesPath:
      response = await getRoutes();
      break;
    case event.httpMethod === 'POST' && event.path === routePath:
      response = await saveRoute(JSON.parse(event.body));
      break;
    case event.httpMethod === 'PATCH' && event.path === routePath:
      const requestBody = JSON.parse(event.body);
      response = await modifyRoute(requestBody.userid, requestBody.updateKey, requestBody.updateValue);
      break;
    case event.httpMethod === 'DELETE' && event.path === routePath:
      response = await deleteRoute(JSON.parse(event.body).userid);
      break;
    default:
      response = buildResponse(404, '404 Not Found');
  }
  return response;
}

async function getRoute(userid) {
  const params = {
    TableName: dynamodbTableName,
    Key: {
      'userid': userid
    }
  }
  return await dynamodb.get(params).promise().then((response) => {
    return buildResponse(200, response.Item);
  }, (error) => {
    console.error('Do your custom error handling here. I am just gonna log it: ', error);
  });
}

async function getRoutes() {
  const params = {
    TableName: dynamodbTableName
  }
  const allRoutes = await scanDynamoRecords(params, []);
  const body = {
    routes: allRoutes
  }
  return buildResponse(200, body);
}

async function scanDynamoRecords(scanParams, itemArray) {
  try {
    const dynamoData = await dynamodb.scan(scanParams).promise();
    itemArray = itemArray.concat(dynamoData.Items);
    if (dynamoData.LastEvaluatedKey) {
      scanParams.ExclusiveStartkey = dynamoData.LastEvaluatedKey;
      return await scanDynamoRecords(scanParams, itemArray);
    }
    return itemArray;
  } catch(error) {
    console.error('Do your custom error handling here. I am just gonna log it: ', error);
  }
}

async function saveRoute(requestBody) {
  const params = {
    TableName: dynamodbTableName,
    Item: requestBody
  }
  return await dynamodb.put(params).promise().then(() => {
    const body = {
      Operation: 'SAVE',
      Message: 'SUCCESS',
      Item: requestBody
    }
    return buildResponse(200, body);
  }, (error) => {
    console.error('Do your custom error handling here. I am just gonna log it: ', error);
  })
}

async function modifyRoute(userid, updateKey, updateValue) {
  const params = {
    TableName: dynamodbTableName,
    Key: {
      'userid': userid
    },
    UpdateExpression: `set ${updateKey} = :value`,
    ExpressionAttributeValues: {
      ':value': updateValue
    },
    ReturnValues: 'UPDATED_NEW'
  }
  return await dynamodb.update(params).promise().then((response) => {
    const body = {
      Operation: 'UPDATE',
      Message: 'SUCCESS',
      UpdatedAttributes: response
    }
    return buildResponse(200, body);
  }, (error) => {
    console.error('Do your custom error handling here. I am just gonna log it: ', error);
  })
}

async function deleteRoute(userid) {
  const params = {
    TableName: dynamodbTableName,
    Key: {
      'userid': userid
    },
    ReturnValues: 'ALL_OLD'
  }
  return await dynamodb.delete(params).promise().then((response) => {
    const body = {
      Operation: 'DELETE',
      Message: 'SUCCESS',
      Item: response
    }
    return buildResponse(200, body);
  }, (error) => {
    console.error('Do your custom error handling here. I am just gonna log it: ', error);
  })
}

function buildResponse(statusCode, body) {
  return {
    statusCode: statusCode,
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(body)
  }
}