const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({ region: 'eu-west-1' });

//

exports.handler = (event, context, callback) => {
 
    var params = {
  TableName: 'Forum_Boards_Info',
  FilterExpression : "contains(#boardID, :boardID)",
    ExpressionAttributeNames: { "#boardID": "boardID" },
    ExpressionAttributeValues: {
        ':boardID': event["queryStringParameters"]['boardID']

    }
    }

    docClient.scan(params, function (err, data) {
      if (err) {
        console.log(err, err.stack) // an error occurred
      } else {
        console.log(data) // successful response
        callback(null, data.Items)
      }
    })
 
  }



