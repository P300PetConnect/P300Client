/*var pg = require("pg");

test();
 function test (event, context) {

  console.log("test");
    var conn = "Host=petconnect.cluster-ro-cofkqdav0xcm.eu-west-1.rds.amazonaws.com;Port=5425;Username=postgres;Password=admin2022;Database=petconnect;";
    var client = new pg.Client(conn);
    client.connect();

    //var id = event.id;
    console.log('Connected to PostgreSQL database');
    var query = client.query("SELECT * from UserTBL;");
    query.on("row", function (row, result) {
        result.addRow(row);
    });
    
    query.on("end", function (result) {
        var jsonString = JSON.stringify(result.rows);
        var jsonObj = JSON.parse(jsonString);
        console.log(jsonString);
        client.end();
        context.succeed(jsonObj);
    });
};
*/


  const { Client } = require('pg');
  const client = new Client({
                   user: "postgres",
                   host: "petconnect.cluster-ro-cofkqdav0xcm.eu-west-1.rds.amazonaws.com",
                   database: "petconnect",
                   password: "admin2022",
                   port: 5425
                 });
 client.connect();
  const res =  client.query('SELECT * from UserTBL')
  console.log(res) // Hello world!
   client.end()

