const AWS = require('aws-sdk');
const ddb = new AWS.DynamoDB.DocumentClient({ region: 'eu-west-1' });

exports.handler = async (event, context) => {
     try{
       const response = {
       statusCode: 204,
       headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin':'*'
    },
    body: "test"
    };
    let ddbParams = {
          TableName: 'Forum-Data',
  Item: {                
                'PostID' : event.PostID,
                'PostTitle': event.PostTitle,
                'BoardID' : event.BoardID,
                'User': event.User,
                'Content':  event.Content,
                'Date': event.Date,
                
                'DisplayComments': event.DisplayComments, 
                'VoteCount': event.VoteCount
        }
        };
        
        console.log(ddbParams)

    await ddb.put(ddbParams).promise();
    return response;
    
    }catch(err){
        console.log("Error", err);
      
    }
   
   console.log("Success: Everything executed correctly");
        context.done(null, event);
};

