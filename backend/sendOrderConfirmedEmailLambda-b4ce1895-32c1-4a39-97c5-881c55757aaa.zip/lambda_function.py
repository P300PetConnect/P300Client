import json
import boto3

def lambda_handler(event, context):
    client = boto3.client("ses")
    subject = "Your Order Is Confirmed!"
    body = "<img src='https://s3-images-web-ca2.s3.eu-west-1.amazonaws.com/emaillogo.png' width='100%' height='100%' alt='logo'><h1>Hello User!</h1><br><p>Your order has been confirmed</p>"
    message = {"Subject": {"Data": subject}, "Body": {"Html": {"Data": body}}}
    response = client.send_email(Source = "petconnectapp@outlook.com",
               Destination = {"ToAddresses": ["akmenz@yahoo.ie"]}, Message = message)
    return response
