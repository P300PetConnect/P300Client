var AWS = require('aws-sdk');
    AWS.config.update({region: 'eu-west-1'});


export const handler = async(event) => {
    
    console.log(event.body.name) 
    // Load the AWS SDK for Node.js
    
    // Set the region 
    
    // Create the DynamoDB service object
    var ddb = new AWS.DynamoDB({apiVersion: '2012-08-10'});
    
    var params = {
      TableName: 'SaveRouteUsersTable',
      Item: {
        'userID' : {S: '001'},
        'CUSTOMER_NAME' : {S: 'Richard Roe'}
      }
    };
    
    // Call DynamoDB to add the item to the table
    ddb.putItem(params, function(err, data) {
      if (err) {
        console.log("Error", err);
      } else {
        console.log("Success", data);
      }
    });

};
