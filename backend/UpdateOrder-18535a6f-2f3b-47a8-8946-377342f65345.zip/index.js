
 ///UPDATE
 const { Pool } = require('pg')
 
const pool = new Pool({
    user: 'postgres',
    host: 'petconnect.cluster-ro-cofkqdav0xcm.eu-west-1.rds.amazonaws.com',
    database: 'petconnect',
    password: 'admin2022',
    port: 5425
});

exports.handler = async (event, context, callback) => {
    
    let OrderID = 96;
    let PetSitterID = event.PetSitterID;
    let PetOwnerID = event.PetOwnerID;
    let OrderDate = event.OrderDate;
    let Description = event.Description;
    let Status = event.Status;
    let ServiceID = event.ServiceID; 
    let Price = event.Price; 
    let PaymentStatus = event.PaymentStatus; 
    
    let data = []; 
    
    pool.query(`UPDATE public."OrderTBL" SET "PetSitterID" = ${PetSitterID},"PetOwnerID"=${PetOwnerID},"OrderDate"='${OrderDate}',"Description"='${Description}', "Status"=${Status}
    WHERE "OrderID" = ${OrderID};
    UPDATE public."OrderDetailsTBL" SET "OrderID"=${OrderID},"ServiceID"=${ServiceID}, "Price"=${Price}, "PaymentStatus"=${PaymentStatus}
    WHERE "OrderID" = ${OrderID}`)
    .then((res)=> data = res.rows)
    .catch((err) => console.log(err))
    pool.end; 
    
    return{
        statusCode:200, 
        body: JSON.stringify(data)
    }
 };

