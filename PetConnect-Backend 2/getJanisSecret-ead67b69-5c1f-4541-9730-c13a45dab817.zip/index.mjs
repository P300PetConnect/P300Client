export const handler = async(event) => {
    // TODO implement
    const response = {
        statusCode: 200,
        body: JSON.stringify('377aKPFc8Qo+5jbhACa+79neBuAuNigtBIOEtbd9'),
    };
    return response;
};