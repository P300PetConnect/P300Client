//this imports the postgres connector into the file so it can be used
//const { Client } = require('pg');
const { Pool } = require('pg')
var result;
const pool = new Pool({
    user: 'postgres',
    host: 'petconnect.cluster-ro-cofkqdav0xcm.eu-west-1.rds.amazonaws.com',
    database: 'petconnect',
    password: 'admin2022',
    port: 5425
});
//the lambda funtion code
exports.handler = async (event, context, callback) => {
let PetSitterID = parseInt(event["queryStringParameters"]['id'])
//let id = event.id; 


var getOrders = 
`SELECT *
FROM Public."OrderTBL" 
Where "PetSitterID"=${PetSitterID} AND "FlagReadPetSitter"='false'`
    try {
const client = await pool.connect()
result = await client.query({
  text: getOrders,
})
console.log(result.fields[0].name) // one
console.log(PetSitterID) // two
console.log(result.rows) 
    } catch (err) {
        callback(null, "Failed to Connect Successfully");
        throw err;
        //error message
    }
let message = {
   'message': 'Execution started successfully!'
}
return {
    'statusCode': 200,
    'headers': {'Content-Type': 'application/json'},
    'body': JSON.stringify(result.rows)
}
};